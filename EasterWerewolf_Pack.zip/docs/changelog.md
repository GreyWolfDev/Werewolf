
# Changelog - Easter Update

- Added new seasonal roles: Egg and Egg Hunter
- Added achievement: Today’s Special (crack 7 Eggs in one game)
- Added Farsi translations for all new content
